library(testthat)
library(fmrilss)

test_check("fmrilss") 